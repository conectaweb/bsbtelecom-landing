
'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { api } from '@/lib/api-client';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Phone, Mail, MapPin, Calendar, Loader2 } from 'lucide-react';

interface ContactRequest {
  id: number;
  full_name: string;
  phone: string;
  email?: string;
  address: string;
  plan_name?: string;
  message?: string;
  status: string;
  created_at: string;
}

export default function AdminPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [requests, setRequests] = useState<ContactRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    if (!isLoading && (!user || !user.isAdmin)) {
      router.push('/');
    }
  }, [user, isLoading, router]);

  useEffect(() => {
    if (user?.isAdmin) {
      fetchRequests();
    }
  }, [user, statusFilter]);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const params: Record<string, string> | undefined =
        statusFilter !== 'all' ? { status: statusFilter } : undefined;
      const data = await api.get<ContactRequest[]>('/contact-requests', params);
      setRequests(data);
    } catch (error) {
      toast.error('Erro ao carregar solicitações');
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id: number, newStatus: string) => {
    try {
      await api.put(`/contact-requests?id=${id}`, { status: newStatus });
      toast.success('Status atualizado com sucesso');
      fetchRequests();
    } catch (error) {
      toast.error('Erro ao atualizar status');
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      pending: 'default',
      contacted: 'secondary',
      converted: 'outline',
      cancelled: 'destructive',
    };

    const labels: Record<string, string> = {
      pending: 'Pendente',
      contacted: 'Contatado',
      converted: 'Convertido',
      cancelled: 'Cancelado',
    };

    return (
      <Badge variant={variants[status] || 'default'}>
        {labels[status] || status}
      </Badge>
    );
  };

  if (isLoading || !user?.isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">Painel Administrativo</h1>
            <Button onClick={() => router.push('/')} variant="outline">
              Voltar ao Site
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs value={statusFilter} onValueChange={setStatusFilter}>
          <TabsList className="mb-6">
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="pending">Pendentes</TabsTrigger>
            <TabsTrigger value="contacted">Contatadas</TabsTrigger>
            <TabsTrigger value="converted">Convertidas</TabsTrigger>
            <TabsTrigger value="cancelled">Canceladas</TabsTrigger>
          </TabsList>

          <TabsContent value={statusFilter}>
            {loading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin" />
              </div>
            ) : requests.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  Nenhuma solicitação encontrada
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {requests.map((request) => (
                  <Card key={request.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle>{request.full_name}</CardTitle>
                          <CardDescription className="flex items-center gap-2 mt-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(request.created_at).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </CardDescription>
                        </div>
                        {getStatusBadge(request.status)}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span>{request.phone}</span>
                        </div>
                        {request.email && (
                          <div className="flex items-center gap-2 text-sm">
                            <Mail className="h-4 w-4 text-muted-foreground" />
                            <span>{request.email}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex items-start gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <span>{request.address}</span>
                      </div>

                      {request.plan_name && (
                        <div className="text-sm">
                          <span className="font-medium">Plano de interesse:</span> {request.plan_name}
                        </div>
                      )}

                      {request.message && (
                        <div className="text-sm">
                          <span className="font-medium">Mensagem:</span>
                          <p className="mt-1 text-muted-foreground">{request.message}</p>
                        </div>
                      )}

                      <div className="flex gap-2 pt-4 border-t">
                        {request.status === 'pending' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => updateStatus(request.id, 'contacted')}
                            >
                              Marcar como Contatado
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateStatus(request.id, 'cancelled')}
                            >
                              Cancelar
                            </Button>
                          </>
                        )}
                        {request.status === 'contacted' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => updateStatus(request.id, 'converted')}
                            >
                              Marcar como Convertido
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateStatus(request.id, 'pending')}
                            >
                              Voltar para Pendente
                            </Button>
                          </>
                        )}
                        {(request.status === 'converted' || request.status === 'cancelled') && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateStatus(request.id, 'pending')}
                          >
                            Reabrir
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
