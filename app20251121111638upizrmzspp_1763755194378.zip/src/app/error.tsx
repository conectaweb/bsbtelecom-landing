"use client";

export { default } from "@/components/Error";
