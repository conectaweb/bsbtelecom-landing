
import { Header } from '@/components/landing/Header';
import { Hero } from '@/components/landing/Hero';
import { Plans } from '@/components/landing/Plans';
import { About } from '@/components/landing/About';
import { Contact } from '@/components/landing/Contact';
import { Footer } from '@/components/landing/Footer';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Plans />
        <About />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
