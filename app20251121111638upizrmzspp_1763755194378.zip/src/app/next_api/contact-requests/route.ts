
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";

export const GET = requestMiddleware(async (request, context) => {
  const { limit, offset, search } = parseQueryParams(request);
  const searchParams = request.nextUrl.searchParams;
  const status = searchParams.get("status");
  
  const contactRequestsCrud = new CrudOperations("contact_requests", context.token);
  
  const filters: Record<string, any> = {};
  if (status) {
    filters.status = status;
  }
  
  const data = await contactRequestsCrud.findMany(filters, { 
    limit, 
    offset,
    orderBy: {
      column: 'created_at',
      direction: 'desc'
    }
  });
  
  return createSuccessResponse(data);
}, true);

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  
  if (!body.full_name || !body.phone || !body.address) {
    return createErrorResponse({
      errorMessage: "Nome completo, telefone e endereço são obrigatórios",
      status: 400,
    });
  }
  
  const contactRequestsCrud = new CrudOperations("contact_requests", context.token);
  
  const user_id = context.payload?.sub;
  
  const data = await contactRequestsCrud.create({ 
    ...body, 
    user_id,
    status: 'pending'
  });
  
  return createSuccessResponse(data, 201);
}, false);

export const PUT = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);
  
  if (!id) {
    return createErrorResponse({
      errorMessage: "ID é obrigatório",
      status: 400,
    });
  }
  
  const body = await validateRequestBody(request);
  const contactRequestsCrud = new CrudOperations("contact_requests", context.token);
  
  const existing = await contactRequestsCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Solicitação não encontrada",
      status: 404,
    });
  }
  
  const data = await contactRequestsCrud.update(id, body);
  return createSuccessResponse(data);
}, true);

export const DELETE = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);
  
  if (!id) {
    return createErrorResponse({
      errorMessage: "ID é obrigatório",
      status: 400,
    });
  }
  
  const contactRequestsCrud = new CrudOperations("contact_requests", context.token);
  
  const existing = await contactRequestsCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Solicitação não encontrada",
      status: 404,
    });
  }
  
  const data = await contactRequestsCrud.delete(id);
  return createSuccessResponse(data);
}, true);
