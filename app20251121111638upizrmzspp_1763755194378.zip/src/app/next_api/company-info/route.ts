
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams, validateRequestBody } from "@/lib/api-utils";

export const GET = requestMiddleware(async (request, context) => {
  const companyInfoCrud = new CrudOperations("company_info", context.token);
  
  const data = await companyInfoCrud.findMany({}, { limit: 1, offset: 0 });
  
  if (data && data.length > 0) {
    return createSuccessResponse(data[0]);
  }
  
  return createSuccessResponse(null);
}, false);

export const POST = requestMiddleware(async (request, context) => {
  const body = await validateRequestBody(request);
  
  if (!body.company_name || !body.phone || !body.address) {
    return createErrorResponse({
      errorMessage: "Nome da empresa, telefone e endereço são obrigatórios",
      status: 400,
    });
  }
  
  const companyInfoCrud = new CrudOperations("company_info", context.token);
  const data = await companyInfoCrud.create(body);
  
  return createSuccessResponse(data, 201);
}, true);

export const PUT = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);
  
  if (!id) {
    return createErrorResponse({
      errorMessage: "ID é obrigatório",
      status: 400,
    });
  }
  
  const body = await validateRequestBody(request);
  const companyInfoCrud = new CrudOperations("company_info", context.token);
  
  const existing = await companyInfoCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Informações da empresa não encontradas",
      status: 404,
    });
  }
  
  const data = await companyInfoCrud.update(id, body);
  return createSuccessResponse(data);
}, true);
