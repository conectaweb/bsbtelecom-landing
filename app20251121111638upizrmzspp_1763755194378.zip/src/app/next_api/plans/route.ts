
import CrudOperations from '@/lib/crud-operations';
import { createSuccessResponse, createErrorResponse } from '@/lib/create-response';
import { requestMiddleware, parseQueryParams } from "@/lib/api-utils";

export const GET = requestMiddleware(async (request, context) => {
  const { limit, offset } = parseQueryParams(request);
  
  const plansCrud = new CrudOperations("plans", context.token);
  
  const filters = { is_active: true };
  
  const data = await plansCrud.findMany(filters, { 
    limit, 
    offset,
    orderBy: {
      column: 'display_order',
      direction: 'asc'
    }
  });
  
  return createSuccessResponse(data);
}, false);

export const POST = requestMiddleware(async (request, context) => {
  const body = await request.json();
  
  if (!body.name || !body.speed || !body.price) {
    return createErrorResponse({
      errorMessage: "Nome, velocidade e preço são obrigatórios",
      status: 400,
    });
  }
  
  const plansCrud = new CrudOperations("plans", context.token);
  const data = await plansCrud.create(body);
  
  return createSuccessResponse(data, 201);
}, true);

export const PUT = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);
  
  if (!id) {
    return createErrorResponse({
      errorMessage: "ID é obrigatório",
      status: 400,
    });
  }
  
  const body = await request.json();
  const plansCrud = new CrudOperations("plans", context.token);
  
  const existing = await plansCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Plano não encontrado",
      status: 404,
    });
  }
  
  const data = await plansCrud.update(id, body);
  return createSuccessResponse(data);
}, true);

export const DELETE = requestMiddleware(async (request, context) => {
  const { id } = parseQueryParams(request);
  
  if (!id) {
    return createErrorResponse({
      errorMessage: "ID é obrigatório",
      status: 400,
    });
  }
  
  const plansCrud = new CrudOperations("plans", context.token);
  
  const existing = await plansCrud.findById(id);
  if (!existing) {
    return createErrorResponse({
      errorMessage: "Plano não encontrado",
      status: 404,
    });
  }
  
  const data = await plansCrud.delete(id);
  return createSuccessResponse(data);
}, true);
