
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, Wifi } from 'lucide-react';
import { ThemeToggle } from '@/components/ThemeToggle';
import { useAuth } from '@/components/auth/AuthProvider';
import { useRouter } from 'next/navigation';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const router = useRouter();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const handleClientArea = () => {
    if (user) {
      if (user.isAdmin) {
        router.push('/admin');
      } else {
        window.location.href = 'https://bsbtelecom.com.br';
      }
    } else {
      router.push('/login');
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Wifi className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">bsbtelecom</span>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <button
              onClick={() => scrollToSection('home')}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Início
            </button>
            <button
              onClick={() => scrollToSection('plans')}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Planos
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-sm font-medium hover:text-primary transition-colors"
            >
              Contato
            </button>
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <ThemeToggle />
            {user ? (
              <>
                <Button onClick={handleClientArea} variant="outline" size="sm">
                  {user.isAdmin ? 'Painel Admin' : 'Área do Cliente'}
                </Button>
                <Button onClick={logout} variant="ghost" size="sm">
                  Sair
                </Button>
              </>
            ) : (
              <Button onClick={handleClientArea} size="sm">
                Área do Cliente
              </Button>
            )}
          </div>

          <div className="md:hidden flex items-center gap-2">
            <ThemeToggle />
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <button
              onClick={() => scrollToSection('home')}
              className="block w-full text-left py-2 text-sm font-medium hover:text-primary transition-colors"
            >
              Início
            </button>
            <button
              onClick={() => scrollToSection('plans')}
              className="block w-full text-left py-2 text-sm font-medium hover:text-primary transition-colors"
            >
              Planos
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="block w-full text-left py-2 text-sm font-medium hover:text-primary transition-colors"
            >
              Sobre
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="block w-full text-left py-2 text-sm font-medium hover:text-primary transition-colors"
            >
              Contato
            </button>
            <div className="pt-4 border-t">
              {user ? (
                <>
                  <Button onClick={handleClientArea} variant="outline" size="sm" className="w-full mb-2">
                    {user.isAdmin ? 'Painel Admin' : 'Área do Cliente'}
                  </Button>
                  <Button onClick={logout} variant="ghost" size="sm" className="w-full">
                    Sair
                  </Button>
                </>
              ) : (
                <Button onClick={handleClientArea} size="sm" className="w-full">
                  Área do Cliente
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
