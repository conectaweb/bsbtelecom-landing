
'use client';

import { Button } from '@/components/ui/button';
import { Wifi, MapPin } from 'lucide-react';

export function Hero() {
  const scrollToPlans = () => {
    const element = document.getElementById('plans');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2070)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'brightness(0.4)',
        }}
      />
      
      <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/30 to-background z-10" />

      <div className="container mx-auto px-4 relative z-20 text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">Sertão da Barra do Una, São Sebastião - SP</span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
            Internet de Alta Velocidade
            <br />
            <span className="text-primary">no Coração da Natureza</span>
          </h1>

          <p className="text-lg md:text-xl text-gray-200 max-w-2xl mx-auto">
            Conectando você ao mundo digital em meio aos recursos naturais do Sertão da Barra do Una. 
            Internet banda larga de qualidade para sua casa e empresa.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <Button onClick={scrollToPlans} size="lg" className="text-lg px-8">
              <Wifi className="mr-2 h-5 w-5" />
              Ver Planos
            </Button>
            <Button onClick={scrollToContact} size="lg" variant="outline" className="text-lg px-8">
              Fale Conosco
            </Button>
          </div>

          <div className="pt-8 flex flex-wrap justify-center gap-8 text-white">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">100%</div>
              <div className="text-sm text-gray-300">Cobertura Rural</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">24/7</div>
              <div className="text-sm text-gray-300">Suporte Local</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">ANATEL</div>
              <div className="text-sm text-gray-300">Outorgado</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
