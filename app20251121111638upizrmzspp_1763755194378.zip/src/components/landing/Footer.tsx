
'use client';

import { useEffect, useState } from 'react';
import { MapPin, Phone, Mail, Shield } from 'lucide-react';
import { api } from '@/lib/api-client';

interface CompanyInfo {
  company_name: string;
  phone: string;
  whatsapp?: string;
  email?: string;
  address: string;
  city?: string;
  state?: string;
  zip_code?: string;
  anatel_license?: string;
}

export function Footer() {
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);

  useEffect(() => {
    fetchCompanyInfo();
  }, []);

  const fetchCompanyInfo = async () => {
    try {
      const data = await api.get<CompanyInfo>('/company-info');
      setCompanyInfo(data);
    } catch (error) {
      console.error('Erro ao carregar informações da empresa');
    }
  };

  const defaultInfo: CompanyInfo = {
    company_name: 'bsbtelecom - internet banda larga',
    phone: '(19) 4040-4715',
    whatsapp: '(19) 4040-4715',
    email: 'contato@bsbtelecom.com.br',
    address: 'Rua Arnaldo Mamprin, 20',
    city: 'Vinhedo',
    state: 'SP',
    zip_code: '13248-408',
    anatel_license: 'Outorgado pela ANATEL',
  };

  const info: CompanyInfo = companyInfo || defaultInfo;

  return (
    <footer className="bg-muted/50 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4">{info.company_name}</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Conectando você ao mundo digital no coração da natureza. Internet de qualidade para o Sertão da Barra do Una.
            </p>
            {info.anatel_license && (
              <div className="flex items-center gap-2 text-sm">
                <Shield className="h-4 w-4 text-primary" />
                <span className="font-medium text-primary">{info.anatel_license}</span>
              </div>
            )}
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Contato</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-2 text-sm">
                <Phone className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                <div>
                  <div>{info.phone}</div>
                  {info.whatsapp && (
                    <div className="text-muted-foreground">
                      WhatsApp: {info.whatsapp}
                    </div>
                  )}
                </div>
              </div>
              {info.email && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <span>{info.email}</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Localização</h3>
            <div className="flex items-start gap-2 text-sm">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
              <div>
                <div>{info.address}</div>
                <div className="text-muted-foreground">Parque Santa Candida</div>
                {info.city && info.state && (
                  <div className="text-muted-foreground">
                    {info.city}/{info.state}
                  </div>
                )}
                {info.zip_code && (
                  <div className="text-muted-foreground">
                    CEP: {info.zip_code}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>
            &copy; {new Date().getFullYear()} {info.company_name}. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
