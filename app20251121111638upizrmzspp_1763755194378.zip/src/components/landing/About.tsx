
'use client';

import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Shield, Headphones, Zap } from 'lucide-react';

export function About() {
  const features = [
    {
      icon: MapPin,
      title: 'Cobertura Rural',
      description: 'Atendimento especializado para o Sertão da Barra do Una e região, levando internet de qualidade onde outros não chegam.',
    },
    {
      icon: Shield,
      title: 'Outorgado ANATEL',
      description: 'Empresa regularizada e outorgada pela ANATEL, garantindo qualidade e segurança nos serviços prestados.',
    },
    {
      icon: Headphones,
      title: 'Suporte Local',
      description: 'Equipe técnica local disponível 24/7 para atendimento rápido e personalizado quando você precisar.',
    },
    {
      icon: Zap,
      title: 'Alta Velocidade',
      description: 'Tecnologia de ponta para garantir conexão estável e veloz, ideal para trabalho, estudo e entretenimento.',
    },
  ];

  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Sobre o Sertão da Barra do Una</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Localizado em São Sebastião, SP, o Sertão da Barra do Una é um vilarejo rural cercado por recursos naturais 
            exuberantes. Montanhas, vegetação nativa e tranquilidade se unem à tecnologia através da BSBTelecom, 
            proporcionando conectividade de qualidade em meio à natureza.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-16">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div 
            className="relative h-64 rounded-lg overflow-hidden"
            style={{
              backgroundImage: 'url(https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=2071)',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
              <span className="text-white font-semibold">Natureza Preservada</span>
            </div>
          </div>
          <div 
            className="relative h-64 rounded-lg overflow-hidden"
            style={{
              backgroundImage: 'url(https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2070)',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
              <span className="text-white font-semibold">Paisagens Deslumbrantes</span>
            </div>
          </div>
          <div 
            className="relative h-64 rounded-lg overflow-hidden"
            style={{
              backgroundImage: 'url(https://images.unsplash.com/photo-1511497584788-876760111969?q=80&w=2232)',
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
              <span className="text-white font-semibold">Comunidade Acolhedora</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
