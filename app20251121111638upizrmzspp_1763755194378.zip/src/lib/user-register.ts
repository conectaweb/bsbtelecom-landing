
import CrudOperations from '@/lib/crud-operations';
import { generateAdminUserToken } from '@/lib/auth';

export async function userRegisterCallback(user: {
  id: string;
  email: string;
  role: string;
}): Promise<void> {
  try {
    const adminToken = await generateAdminUserToken();
    const profilesCrud = new CrudOperations("user_profiles", adminToken);

    const basicProfile = {
      user_id: user.id,
      full_name: user.email.split('@')[0],
      is_active: true,
    };

    await profilesCrud.create(basicProfile);
    console.log(`Perfil básico criado para o usuário ${user.id}`);
  } catch (error) {
    console.error('Falha ao criar perfil do usuário:', error);
  }
}
